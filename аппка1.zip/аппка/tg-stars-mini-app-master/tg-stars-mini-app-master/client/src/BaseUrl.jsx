const config = {
  baseUrl: "YOUR_HOST",
};

export default config;
